from django.db import models

class Producto(models.Model):
    id_producto = models.AutoField(primary_key=True)
    id_categoria = models.IntegerField()
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField()
    precio_base = models.DecimalField(max_digits=10, decimal_places=2)
    imagen_url = models.CharField(max_length=255, null=True, blank=True)
    stock_actual = models.IntegerField()

    class Meta:
        db_table = 'productos'

    def __str__(self):
        return self.nombre