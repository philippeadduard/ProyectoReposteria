from django.contrib import admin
from django.urls import path
from gestion.views import lista_productos

urlpatterns = [
    path('', lista_productos),
    path('admin/', admin.site.urls),
]